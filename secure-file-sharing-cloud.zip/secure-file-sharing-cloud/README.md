# secure serverless file sharing system

## project overview
This project implements a secure serverless file sharing system using cloud services. The system allows users to upload files through a secure API and receive a temporary download link. The design focuses on cloud security, scalability, and cost efficiency.

## cloud services used
- AWS S3: Encrypted storage for uploaded files
- AWS Lambda: Serverless backend logic
- Amazon API Gateway: Secure HTTPS interface
- AWS IAM: Access control using least-privilege roles
- Amazon CloudWatch: Logging and monitoring
- GitHub Actions: CI/CD automation

## system features
- Serverless architecture
- Encryption at rest and in transit
- Temporary pre-signed download links
- Least-privilege IAM configuration
- Centralized logging and monitoring
- Automated CI pipeline

## project structure
secure-file-sharing-cloud/
├── lambda/
│ └── app.py
├── iam/
│ └── policy.json
├── cicd/
│ └── github-actions.yml
├── docs/
│ ├── architecture.md
│ ├── security-analysis.md
│ └── threat-model.md
├── tests/
│ └── test-cases.md
├── README.md
└── report.md

## deployment steps (high-level)
1. Create an encrypted S3 bucket.
2. Create an IAM role and attach the provided least-privilege policy.
3. Deploy the Lambda function using the provided source code.
4. Configure API Gateway to trigger the Lambda function over HTTPS.
5. Enable CloudWatch logging.
6. Push the code to GitHub to activate the CI pipeline.

## usage
- Send an HTTPS request with file content in the request body.
- Receive a temporary download URL in the response.
- Use the link before it expires to download the file.

## testing
Functional and security test cases are documented in `tests/test-cases.md`.

## security notes
- No credentials are hardcoded in the source code.
- Access to files is time-limited and controlled.
- All cloud permissions follow the principle of least privilege.

## limitations and future improvements
- Support for larger file uploads
- User authentication and authorization
- Enhanced monitoring and alerting

## author
Course project submission
