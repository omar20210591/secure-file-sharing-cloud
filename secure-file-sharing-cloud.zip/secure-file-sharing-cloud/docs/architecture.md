# system architecture

## overview
This project is a secure file sharing system built using cloud services. The main idea is to allow user upload files safely and get a temporary download link. The system is serverless so no need to manage any server and it can scale automatically when users increase.

## architecture components
- AWS Lambda Function URL: Used as secure HTTPS endpoint where user send request.
- AWS Lambda: Contains main backend logic like validating input and uploading file.
- Amazon S3: Used to store uploaded files securely in private bucket.
- AWS IAM: Controls permissions for Lambda using least privilege access.
- Amazon CloudWatch: Used to store logs and monitor Lambda execution.
- GitHub Actions: Used for CI/CD to automate code updates.

## data flow
1. User sends HTTP POST request with filename and content.
2. Request goes to AWS Lambda Function URL.
3. Lambda function validates request data.
4. File is uploaded to private Amazon S3 bucket.
5. Lambda creates a pre-signed URL with expiry time.
6. Response is sent back to user in JSON format.
7. Logs are stored in CloudWatch for monitoring.

## architecture diagram (logical view)

User  
  |  
  | HTTPS request (JSON)  
  v  
AWS Lambda Function URL  
  |  
  v  
AWS Lambda  
  |  
  v  
Private Amazon S3 Bucket  
  ^  
  |  
IAM Role (limited permissions)  

CloudWatch Logs (monitoring)

**Figure 1:** Secure file sharing system architecture using AWS serverless services
