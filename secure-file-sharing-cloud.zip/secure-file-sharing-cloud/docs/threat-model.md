# threat model

## identified threats
This section explains the possible security threats that may affect the system.

1. Unauthorized access to uploaded files  
2. Data leakage during file upload or download  
3. Misuse or abuse of cloud resources  
4. Compromise of Lambda function permissions  
5. Accidental exposure due to wrong configuration  

## threat analysis and mitigation

### 1. unauthorized access to files
- risk: An attacker may try to access files directly from cloud storage.
- mitigation: The Amazon S3 bucket is private and public access is fully blocked. Files can only be accessed using time-limited pre-signed URLs.

### 2. data leakage during transmission
- risk: File data could be intercepted while being uploaded or downloaded.
- mitigation: All communication uses HTTPS which encrypts data during transfer.

### 3. excessive iam permissions
- risk: If IAM permissions are too broad, the Lambda function could perform unwanted actions.
- mitigation: Least privilege principle is applied. Lambda can only access required S3 actions and CloudWatch logs.

### 4. cloud service abuse
- risk: Repeated requests could overload the system or increase cloud cost.
- mitigation: Serverless design reduces attack impact, and API Gateway throttling can be enabled if needed.

### 5. lack of monitoring
- risk: Security problems may not be detected early.
- mitigation: Amazon CloudWatch logs all Lambda executions, errors, and access attempts.

## security posture summary
The system follows a layered security approach using IAM access control, encrypted communication, private storage, and monitoring. These controls help reduce common cloud security threats and limit damage if an issue occurs.
