import json
import boto3
import uuid
import os
import logging

# initialize logger (CloudWatch will capture this)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

BUCKET_NAME = os.environ.get("BUCKET_NAME", "secure-file-sharing-bucket")
URL_EXPIRATION = 300  # seconds (5 minutes)

def lambda_handler(event, context):
    try:
        logger.info("request received")

        if "body" not in event or not event["body"]:
            logger.warning("empty request body")
            return response(400, "no file content provided")

        file_id = str(uuid.uuid4())
        file_name = f"{file_id}.txt"

        # store file with encryption
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=file_name,
            Body=event["body"],
            ServerSideEncryption="AES256"
        )

        # generate temporary secure download link
        presigned_url = s3.generate_presigned_url(
            ClientMethod="get_object",
            Params={
                "Bucket": BUCKET_NAME,
                "Key": file_name
            },
            ExpiresIn=URL_EXPIRATION
        )

        logger.info(f"file stored successfully: {file_name}")

        return response(200, {
            "message": "file uploaded successfully",
            "download_url": presigned_url,
            "expires_in_seconds": URL_EXPIRATION
        })

    except Exception as e:
        logger.error(f"error: {str(e)}")
        return response(500, "internal server error")

def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(body)
    }
